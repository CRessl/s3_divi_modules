<div class="s3dm_cluster_container">

    <?= $content ?>

</div>
<svg height="<?= $this->e($min_height); ?> " width="100%" id="paths">

</svg>

<?php // some js here? ?>

<script>
jQuery(document).ready(function() {
    var windowWidth = jQuery(window).width();
    var linkListContainer = jQuery('.s3dm_cluster_container');
    var itemsToConnect = jQuery('.s3dm_cluster_item_content');

    var itemsToAnimate = itemsToConnect.parents('.s3dm_cluster_item');

    var itemStyle = [];
    connect_items(itemsToConnect);


    // set some global properties
    TweenMax.set(itemsToAnimate, {transformOrigin:"50% 50%"});

    // loop through each element
    itemsToAnimate.each(function(i, el) {
    
        // set some individual properties
        //TweenMax.set(el, {borderRadius:0});

        var tl = new TimelineMax();

        // create your tween of the timeline in a variable
        tl.to(el, {
            x: "random(-15, 15)",
            y: "random(-15, 15)",
            ease: Power3.easeOut,
            duration: 2.5, 
            repeat: -1,
            repeatRefresh: true,
            smoothChildTiming: true
        });

        tl.play();
        // store the tween timeline in the javascript DOM node
        el.animation = tl;
        
        //create the event handler
        jQuery(el).on("mouseenter",function(){
            this.animation.pause();
        }).on("mouseleave",function(){
            this.animation.resume();
        });
    
    });
    
});


function connect_items(items){


    items.each(function(index, item){
        
        var $this = jQuery(this);

        var connectionsString = item.attributes.connections.nodeValue;
        var connections = connectionsString.split(",");

        var currentItem = jQuery(item).parents('.s3dm_cluster_item');

        connections.forEach(function(connectionClass,index){

            var connectionElement = jQuery('[connect_to='+connectionClass+']').parents('.s3dm_cluster_item');

            if(connectionElement.length > 0){

                //then do the connections
                var currentItemWidth = currentItem.get(0).getBoundingClientRect().width;
                var currentItemHeight = currentItem.get(0).getBoundingClientRect().height;
                

                var connectWidth = connectionElement.get(0).getBoundingClientRect().width;
                var connectHeight = connectionElement.get(0).getBoundingClientRect().height;

                var currentItemPositions = currentItem.position();
                var nextItemPositions = connectionElement.position();

                var x1 = currentItemPositions.left + (currentItemWidth /2);
                var y1 = currentItemPositions.top + (currentItemHeight /2);

                var x2 = nextItemPositions.left + (connectWidth / 2);
                var y2 = nextItemPositions.top + (connectHeight / 2);

                var aLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                aLine.setAttribute('x1', x1);
                aLine.setAttribute('y1', y1);
                aLine.setAttribute('x2', x2);
                aLine.setAttribute('y2', y2);
                aLine.setAttribute('stroke', 'black');
                aLine.setAttribute('stroke-width', '2');

                jQuery("#paths").append(aLine);

            }

        });

    });




}
   




</script>