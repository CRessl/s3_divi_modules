
<li>
    <div class="<?= $this->e($prefix) ?>_date">
    <h2>
        <?= $this->e($date); ?>
    </h2>
    </div>
    <div class="<?= $this->e($prefix) ?>_title">
        <h4>
            <?= $this->e($title) ?>
        </h4>
    </div>
    <div class="<?= $this->e($prefix) ?>_link">
        <a href="<?= $this->e($link) ?>" class="uk-button uk-button-default">
            <?= $this->e($button_text) ?>
        </a>
    </div>
</li>