<div class="tab-content">
	<div class="uk-padding-small uk-padding-remove-horizontal">
		<div class="s3dm_tab_nav_category_list uk-grid-small uk-margin" uk-grid>
            <?= $categories ?>
        </div>
		<div class="s3dm_tab_nav_post_title">
            <?= $this->e($title); ?>
        </div>
	</div>
</div> 